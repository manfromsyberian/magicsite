# -*- coding: utf-8 -*-

# Empty models.py, required file for Django tests
